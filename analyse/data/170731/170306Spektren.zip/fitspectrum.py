#!/usr/bin/python3

import numpy as np
import matplotlib.pyplot as plt
import leastsquarefit

def calcsigma(factor, err):
    larmorfrequenz = 97.1722e6 # *2*np.pi
    I=3.0/2.0
    hbar=1.05457180013e-34

    faktorohneeQ=1/larmorfrequenz*(3.0/(2.0*I*(2*I-1.0)))**2*(I*(I+1)-3.0/4.0)
    sigmasq = factor/faktorohneeQ
    lasterror = 1.0/2.0*np.sqrt(1/(faktorohneeQ*factor))*err
    return np.sqrt(sigmasq), lasterror


plt.rcParams['axes.grid'] = False
plt.rcParams['figure.figsize'] = 14.0/2.54, 10.0/2.54
plt.rcParams['xtick.direction'] = 'in'
plt.rcParams['ytick.direction'] = 'in'
plt.rcParams['ytick.right'] = True
plt.rcParams['xtick.top'] = True
plt.rcParams['figure.max_open_warning'] = 200
#plt.rcParams['font.size'] = 12
plt.rcParams['lines.markersize'] = 3.0
plt.rcParams['text.usetex'] = True

freqlimitleft = -130e3
freqlimitright = 100e3


dat = np.loadtxt("15846_CRN_T2_320K/CRN_T2_320K_15846_1.ts.spec.nmr", comments="!")

maska = np.logical_and(dat[:,0] > freqlimitleft, dat[:,0] < freqlimitright)

freqs = dat[maska,0]
spec = dat[maska, 1]


dat2 = np.loadtxt("spectrum.frequency.norm.hist")

simfreqs = -1.0*1/2.0*(dat2[::-1,1]+dat2[::-1,2])
simspec = dat2[::-1,3]

def rescalefreq(f, factor, center):
    return (f - center)*factor

def interpolatespec(x, factor, center, norm):
    tempsimfreq = rescalefreq(simfreqs, factor, center)
    return norm*np.interp(x, tempsimfreq, simspec, left=0.0, right=0.0)

val,err = leastsquarefit.leastsquarefit(freqs, spec, interpolatespec, [1.5e4, 0.0, 50000])

sigma, sigmaerr = calcsigma(val[0], err[0])
print("T=320K\nfactor:\t%f\t+/-\t%f\ncenter:\t%f\t+/-\t%f\nnorm:\t%f\t+/-\t%f\nsigma:\t%E\t+/-\t%E"%(val[0], err[0], val[1], err[1], val[2], err[2], sigma, sigmaerr))

dat = np.loadtxt("575_CRN_T2_340K/CRN_T2_340K_575_1.ts.spec.nmr", comments="!")

maska = np.logical_and(dat[:,0] > freqlimitleft, dat[:,0] < freqlimitright)

freqs2 = dat[maska,0]
spec2 = dat[maska, 1]

val2,err2 = leastsquarefit.leastsquarefit(freqs2, spec2, interpolatespec, [1.5e4, 0.0, 50000])

sigma, sigmaerr = calcsigma(val2[0], err2[0])
print("T=340K\nfactor:\t%f\t+/-\t%f\ncenter:\t%f\t+/-\t%f\nnorm:\t%f\t+/-\t%f\nsigma:\t%E\t+/-\t%E"%(val2[0], err2[0], val2[1], err2[1], val2[2], err2[2], sigma, sigmaerr))

dat = np.loadtxt("842_CRN_T2_350K/CRN_T2_350K_842_1.ts.spec.nmr", comments="!")

maska = np.logical_and(dat[:,0] > freqlimitleft, dat[:,0] < freqlimitright)

freqs3 = dat[maska,0]
spec3 = dat[maska, 1]


val3,err3 = leastsquarefit.leastsquarefit(freqs3, spec3, interpolatespec, [1.5e4, 0.0, 50000])

sigma, sigmaerr = calcsigma(val3[0], err3[0])
print("T=350K\nfactor:\t%f\t+/-\t%f\ncenter:\t%f\t+/-\t%f\nnorm:\t%f\t+/-\t%f\nsigma:\t%E\t+/-\t%E"%(val3[0], err3[0], val3[1], err3[1], val3[2], err3[2], sigma, sigmaerr))

def calcapo(x, factor, center, norm, apo):
    tempsimfreq = rescalefreq(simfreqs, factor, center)
    
    simspecapo = np.zeros(len(simspec))

    for i in range(0,len(simspec)):
        simspecapo += simspec[i]*np.exp(-((tempsimfreq - tempsimfreq[i])/apo)**2)
        
    return norm*np.interp(x, tempsimfreq, simspecapo, left=0.0, right=0.0)


val,err = leastsquarefit.leastsquarefit(freqs, spec, calcapo, [val[0], val[1], val[2], 500], hold=[False, False, False, True])
val2,err2 = leastsquarefit.leastsquarefit(freqs2, spec2, calcapo, [val2[0], val2[1], val2[2], 500], hold=[False, False, False, True])
val3,err3 = leastsquarefit.leastsquarefit(freqs3, spec3, calcapo, [val3[0], val3[1], val3[2], 500], hold=[False, False, False, True])
sigma, sigmaerr = calcsigma(val[0], err[0])
print("T=320K\nfactor:\t%f\t+/-\t%f\ncenter:\t%f\t+/-\t%f\nnorm:\t%f\t+/-\t%f\nsigma:\t%E\t+/-\t%E\napo:\t%f\t+/-\t%f"%(val[0], err[0], val[1], err[1], val[2], err[2], sigma, sigmaerr,  val[3], err[3]))
sigma, sigmaerr = calcsigma(val2[0], err2[0])
print("T=340K\nfactor:\t%f\t+/-\t%f\ncenter:\t%f\t+/-\t%f\nnorm:\t%f\t+/-\t%f\nsigma:\t%E\t+/-\t%E\napo:\t%f\t+/-\t%f"%(val2[0], err2[0], val2[1], err2[1], val2[2], err2[2], sigma, sigmaerr, val2[3], err2[3]))
sigma, sigmaerr = calcsigma(val3[0], err3[0])
print("T=350K\nfactor:\t%f\t+/-\t%f\ncenter:\t%f\t+/-\t%f\nnorm:\t%f\t+/-\t%f\nsigma:\t%E\t+/-\t%E\napo:\t%f\t+/-\t%f"%(val3[0], err3[0], val3[1], err3[1], val3[2], err3[2], sigma, sigmaerr, val3[3], err3[3]))

figure = plt.figure(figsize=(14.0/2.54,14.0/2.54), dpi=600)

axis = figure.add_subplot(1,1,1)

axis.set_yticks([])
axis.set_yticklabels([])
axis.set_ylabel(r"Intensit\"at (a.u.)")
axis.set_xlabel(r"Frequenz $ f $ (kHz)")


axis.set_xlim((-130,100))
axis.set_ylim((0.0, 3.15))

tmpspec=calcapo(freqs, val[0], val[1], val[2], val[3])
mxs = np.max(tmpspec)

axis.plot(freqs/1000.0, spec/(mxs)+2.1, "r-", label="320K", linewidth=1)
#axis.plot(freqs/1000.0, interpolatespec(freqs, val[0], val[1], val[2])/(val[2]*mxs)+2.1, "r--", linewidth=1)
axis.plot(freqs/1000.0, tmpspec/(np.max(tmpspec))+2.1, "r--", linewidth=1)
axis.plot(freqs/1000.0, [2.1]*len(freqs), "k-", linewidth=1)
np.savetxt("320k.dat", np.array([freqs/1000.0, spec/(mxs), tmpspec/(np.max(tmpspec))]).transpose(), fmt="%f", header="f\tmess\tsim", comments="")
tmpspec=calcapo(freqs2, val2[0], val2[1], val2[2], val2[3])
mxs = np.max(tmpspec)
axis.plot(freqs2/1000.0, spec2/(mxs)+1.05, "b-", label="340K", linewidth=1)
#axis.plot(freqs2/1000.0, interpolatespec(freqs2, val2[0], val2[1], val2[2])/(val2[2]*mxs)+1.05, "b--", linewidth=1)
axis.plot(freqs2/1000.0, tmpspec/(np.max(tmpspec))+1.05, "b--", linewidth=1)
axis.plot(freqs2/1000.0, [1.05]*len(freqs2), "k-", linewidth=1)
np.savetxt("340k.dat", np.array([freqs2/1000.0, spec2/(mxs), tmpspec/(np.max(tmpspec))]).transpose(), fmt="%f", header="f\tmess\tsim", comments="")
tmpspec=calcapo(freqs3, val3[0], val3[1], val3[2], val3[3])
mxs = np.max(tmpspec)
axis.plot(freqs3/1000.0, spec3/(mxs), "g-", label="350K", linewidth=1)
#axis.plot(freqs3/1000.0, interpolatespec(freqs3, val3[0], val3[1], val3[2])/(val3[2]*mxs), "g--", linewidth=1)
axis.plot(freqs3/1000.0, tmpspec/(np.max(tmpspec)), "g--", linewidth=1)
np.savetxt("350k.dat", np.array([freqs3/1000.0, spec3/(mxs), tmpspec/(np.max(tmpspec))]).transpose(), fmt="%f", header="f\tmess\tsim", comments="")
axis.legend()

figure.tight_layout()

figure.savefig("crnspectra.pdf")

